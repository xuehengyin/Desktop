#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/5/9 11:29
import os
import pytest
from PubFun.swiftMqReceiver import SwiftMqReceiver
from PubFun.swiftMsg import SwiftMsg

"""报文全流程"""

def test_otherMsgDeal(msg,xldata:dict):
    # 修改报文
    swf = SwiftMsg(msg)

    swf.update(data=xldata)

    msg1 = swf.tostring()

    # 修改后的报文插入数据库
    mqReceiver = SwiftMqReceiver()

    mqReceiver.run(data= msg1)

    print("报文已入表,sysid:",mqReceiver.sys_id)


if __name__ == '__main__':

    pytest.main([os.path.abspath(__file__),'-s'])