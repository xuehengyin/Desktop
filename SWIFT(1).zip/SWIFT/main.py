'''
报文主界面
'''
import sys
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from UI.MSG_HOME import TabWidgetDemo



if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon('images/swift.png'))
    main = TabWidgetDemo()
    main.show()
    sys.exit(app.exec_())