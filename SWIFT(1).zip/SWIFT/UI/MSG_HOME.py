#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/4/27 18:41
'''
报文主界面
'''
import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from MT103_910_202 import test_103_202_OffShore
from MT103_910_202 import test_103_910_OffShore
from MT103 import test_103
from MT_103_Gpi import test_103_GPI
from OTHERMSG.OtherMsg import test_otherMsgDeal
from PubFun.pubFunc import setDataBase
from PubFun.pubFunc import excelData
from PubFun.pubFunc import writeRet
from PubFun.pubFunc import runUi
from PubFun.pubFunc import setUrl
from MT202 import test_202
from MT910 import test_910
import _thread

class TabWidgetDemo(QTabWidget):
    def __init__(self, parent=None):
        super(TabWidgetDemo, self).__init__(parent)

        self.setGeometry(550, 400, 800, 320)
        self.textEdit = QTextEdit()

        self.setWindowTitle("模拟收报")
        # 创建用于显示控件的窗口
        self.tab1 = QWidget()
        self.tab2 = QWidget()

        self.SENDER = QLineEdit()
        self.text_32A = QLineEdit()
        self.text_50K = QPlainTextEdit()
        self.text_59 = QPlainTextEdit()
        self.text_70 = QLineEdit()
        self.text_71A = QLineEdit()

        self.text_msg = QPlainTextEdit()

        self.but_103 = QRadioButton("MT103")
        self.but_103_gpi = QRadioButton("MT103_GPI")
        self.but_103_910 = QRadioButton("MT103_910")
        self.but_103_202 = QRadioButton("MT103_202")
        self.but_910 = QRadioButton("MT910")
        self.but_202 = QRadioButton("MT202")
        self.msgType = ''

        self.but_data_fat1 = QCheckBox("FAT1")
        self.but_data_fat2 = QCheckBox("FAT2")
        self.but_data_fat22 = QCheckBox("FAT22")
        self.dataType = ''

        self.but_data2_fat1 = QCheckBox("FAT1")
        self.but_data2_fat2 = QCheckBox("FAT2")
        self.but_data2_fat22 = QCheckBox("FAT22")
        self.dataType = ''

        self.addTab(self.tab1, "常用报文")
        self.addTab(self.tab2, "其他报文")

        self.if_Ui_Run = QCheckBox("是")
        self.ifUiRun = False

        self.filenames = []

        self.data1 = {}
        self.dataList1 = []
        self.tab1UI()

        self.data2 = {}
        self.tab2UI()

    def tab1UI(self):
        # 表单布局
        layout = QFormLayout()

        layout.addRow("SENDER(发报行):",self.SENDER)
        layout.addRow("32A(起息日币种金额):", self.text_32A)
        layout.addRow("50K(汇款人及详细信息):", self.text_50K)
        layout.addRow("59(收款人):", self.text_59)
        layout.addRow("70(附言):", self.text_70)
        layout.addRow("71A(费用承担方式):", self.text_71A)

        loadmsg = QHBoxLayout()
        self.button2 = QPushButton("加载文本文件")
        self.excelName = QLineEdit()
        self.text_sheet = QLineEdit()
        self.button3 = QPushButton("读取")
        loadmsg.addWidget(self.button2)
        loadmsg.addWidget(QLabel("文件名:"))
        loadmsg.addWidget(self.excelName)
        loadmsg.addWidget(QLabel("sheet名:"))
        loadmsg.addWidget(self.text_sheet)
        loadmsg.addWidget(self.button3)
        layout.addRow(QLabel("数据导入:"), loadmsg)
        self.button2.clicked.connect(self.loadText)
        self.button3.clicked.connect(self.readText)

        datamsg = QHBoxLayout()
        dataType = QButtonGroup(self)
        dataType.setExclusive(True)
        dataType.addButton(self.but_data_fat1)
        dataType.addButton(self.but_data_fat2)
        dataType.addButton(self.but_data_fat22)
        datamsg.addWidget(self.but_data_fat1)
        datamsg.addWidget(self.but_data_fat2)
        datamsg.addWidget(self.but_data_fat22)
        layout.addRow(QLabel("数据库类型:"), datamsg)

        self.but_data_fat1.clicked.connect(self.setDataTypeFat1)
        self.but_data_fat2.clicked.connect(self.setDataTypeFat2)
        self.but_data_fat22.clicked.connect(self.setDataTypeFat22)

        msgType = QHBoxLayout()
        msgType.addWidget(self.but_103)
        msgType.addWidget(self.but_103_gpi)
        msgType.addWidget(self.but_103_910)
        msgType.addWidget(self.but_103_202)
        msgType.addWidget(self.but_910)
        msgType.addWidget(self.but_202)
        layout.addRow(QLabel("报文类型:"), msgType)

        self.but_103.clicked.connect(self.setMsgType103)
        self.but_103_gpi.clicked.connect(self.setMsgType103_gpi)
        self.but_103_910.clicked.connect(self.setMsgType103_910)
        self.but_103_202.clicked.connect(self.setMsgType103_202)
        self.but_202.clicked.connect(self.setMsgType_202)
        self.but_910.clicked.connect(self.setMsgType_910)

        ifUiRun = QHBoxLayout()
        ifUiRun.addWidget(self.if_Ui_Run)
        layout.addRow(QLabel("执行UI:"),ifUiRun)
        self.if_Ui_Run.clicked.connect(self.setUiRun)

        self.tab1.setLayout(layout)
        self.buttonToText = QPushButton("模拟收报")
        layout.addWidget(self.buttonToText)
        self.buttonToText.clicked.connect(self.onClickButtonToText)

    def tab2UI(self):
        # 表单布局
        layout = QFormLayout()
        layout.addRow("请贴入报文:",self.text_msg)

        datamsg = QHBoxLayout()
        dataType = QButtonGroup(self)
        dataType.setExclusive(True)
        dataType.addButton(self.but_data2_fat1)
        dataType.addButton(self.but_data2_fat2)
        dataType.addButton(self.but_data2_fat22)
        datamsg.addWidget(self.but_data2_fat1)
        datamsg.addWidget(self.but_data2_fat2)
        datamsg.addWidget(self.but_data2_fat22)
        layout.addRow(QLabel("数据库类型:"), datamsg)

        self.but_data2_fat1.clicked.connect(self.setDataTypeFat1)
        self.but_data2_fat2.clicked.connect(self.setDataTypeFat2)
        self.but_data2_fat22.clicked.connect(self.setDataTypeFat22)

        self.tab2.setLayout(layout)

        self.buttonToText = QPushButton("模拟收报")
        layout.addWidget(self.buttonToText)
        self.buttonToText.clicked.connect(self.onClickButtonToText2)

    def setDataTypeFat1(self):
        self.dataType = 'FAT1'

    def setDataTypeFat2(self):
        self.dataType = 'FAT2'

    def setDataTypeFat22(self):
        self.dataType = 'FAT22'

    def setMsgType103(self):
        self.msgType = '103'

    def setMsgType103_gpi(self):
        self.msgType = '103_gpi'

    def setMsgType103_910(self):
        self.msgType = '103_910'

    def setMsgType103_202(self):
        self.msgType = '103_202'

    def setMsgType_202(self):
        self.msgType = '202'

    def setMsgType_910(self):
        self.msgType = '910'

    def setUiRun(self):
        self.ifUiRun = True

    def onClickButtonToText(self):
        if self.SENDER.text() :
            if len(self.SENDER.text()) <=35:
                self.data1['SENDER'] = self.SENDER.text()
            else:
                print("SENDER栏位字符串长度超过35！")

        if self.text_32A.text() :
            if len(self.text_32A.text()) <=35:
                self.data1['32A'] = self.text_32A.text()
                if "." in self.data1['32A']:
                    self.data1['32A'] = self.data1['32A'].replace('.',',')
            else:
                print("32A栏位字符串长度超过35！")

        if self.text_50K.toPlainText() :
            if '\n' in self.text_50K.toPlainText() :
                if len(self.text_50K.toPlainText().split('\n')[1]) <=35:
                    self.data1['50K'] = self.text_50K.toPlainText()
                else:
                    print("50K汇款人详细信息栏位字符串长度超过35！")
            else:
                self.data1['50K'] = self.text_50K.toPlainText()

        if self.text_59.toPlainText() :
            if '\n' in self.text_59.toPlainText() :
                if len(self.text_59.toPlainText().split('\n')[1]) <=35:
                    self.data1['59'] = self.text_59.toPlainText()
                else:
                    print("59收款人详细信息栏位字符串长度超过35！")
            else:
                self.data1['59'] = self.text_59.toPlainText()
        if self.text_70.text() :
            if len(self.text_70.text()) <=35:
                self.data1['70'] = self.text_70.text()
            else:
                print("70栏位字符串长度超过35！")
        if self.text_71A.text() :
            if len(self.text_71A.text()) <=35:
                self.data1['71A'] = self.text_71A.text()
            else:
                print("71A栏位字符串长度超过35！")

        print("报文类型为:", self.msgType)
        if self.data1 != {}:
            print("读取结果为:", self.data1)

        # #设置数据库
        print("数据库类型为:",self.dataType)

        setDataBase(self.dataType)

        if self.ifUiRun:

            setUrl(self.dataType)

        if self.msgType == '103':

            def test():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                            ret = test_103.test_msgDeal(self.dataList1[i], self.dataType)

                            if self.ifUiRun:

                                runUi(ret,self.dataType,self.msgType)

                            writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    ret = test_103.test_msgDeal(self.data1,self.dataType)

                    if self.ifUiRun:

                        runUi(ret, self.dataType, self.msgType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test, ())

        if self.msgType == '103_gpi':

            def test():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                        ret = test_103_GPI.test_msgDeal(self.dataList1[i], self.dataType)

                        writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    test_103_GPI.test_msgDeal(self.data1, self.dataType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test,())

        if self.msgType == '103_910':

            def test_103_910():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                        ret = test_103_910_OffShore.test_msgDeal(self.dataList1[i],self.dataType)

                        writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    test_103_910_OffShore.test_msgDeal(self.data1,self.dataType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test_103_910,())

        if self.msgType == '103_202':

            def test_103_202():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                        ret = test_103_202_OffShore.test_msgDeal(self.dataList1[i],self.dataType)

                        writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    test_103_202_OffShore.test_msgDeal(self.data1,self.dataType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test_103_202, ())

        if self.msgType == '202':

            def test():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                        ret = test_202.test_msgDeal(self.dataList1[i], self.dataType)

                        writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    test_202.test_msgDeal(self.data1, self.dataType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test, ())

        if self.msgType == '910':

            def test():

                if len(self.dataList1) > 0:

                    for i in range(0, len(self.dataList1)):

                        ret = test_910.test_msgDeal(self.dataList1[i], self.dataType)

                        writeRet(self.filenames[0], self.text_sheet.text(), ret, i)

                    self.dataList1.clear()

                    print("=======================================本次批量执行完毕=======================================")

                else:

                    test_910.test_msgDeal(self.data1, self.dataType)

                    self.data1.clear()

                    print("=======================================本次批量执行完毕=======================================")

            _thread.start_new_thread(test, ())

    def onClickButtonToText2(self):
        #设置数据库
        print("数据库类型为:", self.dataType)
        setDataBase(self.dataType)

        if self.text_msg.toPlainText():
            test_otherMsgDeal(self.text_msg.toPlainText(),{})

    def loadText(self):
        self.data1.clear()
        dialog = QFileDialog()
        dialog.setFileMode(QFileDialog.AnyFile)
        dialog.setFilter(QDir.Files)
        if dialog.exec():
            self.filenames = dialog.selectedFiles()
            self.excelName.setText(self.filenames[0].split('/')[-1])

    def readText(self):
        self.dataList1 = excelData(self.filenames[0],self.text_sheet.text())
        print(self.dataList1)



if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon('./images/8.png'))
    main = TabWidgetDemo()
    main.show()
    sys.exit(app.exec_())