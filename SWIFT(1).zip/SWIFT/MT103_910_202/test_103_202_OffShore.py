#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/4/20 11:30
import os
import time
import os
from datetime import datetime
from PubFun.swiftMqReceiver import SwiftMqReceiver
from PubFun.swiftMsg import SwiftMsg
from PubFun.pubFunc import sqlData
from PubFun.pubFunc import excelData
from PubFun.pubFunc import waitSWFBatchRun
from PubFun.pubFunc import waitClearBatchRun
from PubFun.pubFunc import waitSettBatchRun
from PubFun.pubFunc import waitAckBatchRun
from PubFun.pubFunc import ifGpiReturn


"""103_202合并报文全流程"""
def test_msgDeal(xldata_103:dict,env):

    ret = {'inbox': '', 'refno': '', 'ifAck': False, 'ifSett': False, 'ifGPI': False}

    xldata_202 = {}

    stime = datetime.now().strftime("%H%M%S")

    sdate = datetime.now().strftime("%y%m%d")

    xldata_202['21'] = 'REF'+sdate+stime

    xldata_202['20'] = sdate+stime

    if '32A' in xldata_103.keys():

        xldata_103['32A'] = xldata_103['32A']

    # 读取103报文
    msgFile_103 = open(f'MSG/{env}/103_OffShore.txt', 'r', encoding='utf-8')

    # 读取202报文
    msgFile_202 = open('MSG/202.txt', 'r', encoding='utf-8')

    # 剔除103报文前后的特殊字符
    msg_103 = msgFile_103.read().replace("","").replace("","")

    # 剔除202报文前后的特殊字符
    msg_202 = msgFile_202.read().replace("", "").replace("", "")

    # 修改103报文
    swf_103 = SwiftMsg(msg_103)

    # 修改202报文
    swf_202 = SwiftMsg(msg_202)

    #更新103报文
    swf_103.update(data=xldata_103)

    # 更新202报文
    swf_202.update(data=xldata_202)

    # 修改后的103报文
    msg_103 = swf_103.tostring()

    # 修改后的202报文
    msg_202 = swf_202.tostring()

    # 修改后的报文插入数据库
    mqReceiver = SwiftMqReceiver()

    # 103报文插入表
    mqReceiver.run(data= msg_103)

    sysid_103 = mqReceiver.sys_id

    print("103报文sysid:",sysid_103)

    # 202报文插入表
    mqReceiver.run(data=msg_202)

    sysid_202 = mqReceiver.sys_id

    print("202报文sysid:",sysid_202)

    # 收报批量执行是否执行成功
    inbox = waitSWFBatchRun(sysid_103)

    print("报文序号:", inbox)

    if inbox:
        ret['inbox'] = inbox

    # 清分批量执行是否执行成功
    refno = waitClearBatchRun(inbox)

    print("业务编号:", refno)

    if refno:

        ret['refno'] = refno

    return ret

if __name__ == '__main__':

    test_msgDeal({},'FAT2')