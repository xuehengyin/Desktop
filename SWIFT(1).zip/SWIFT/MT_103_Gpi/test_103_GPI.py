#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/4/20 11:30
import os
import pytest
from PubFun.swiftMqReceiver import SwiftMqReceiver
from PubFun.swiftMsg import SwiftMsg
from PubFun.pubFunc import waitSWFBatchRun
from PubFun.pubFunc import waitClearBatchRun
from PubFun.pubFunc import waitAckBatchRun
from PubFun.pubFunc import waitSettBatchRun
from PubFun.pubFunc import ifGpiReturn


"""103_GPI报文全流程"""

def test_msgDeal(xldata:dict,env):

    ret = {'inbox': '', 'refno': '', 'ifAck': False, 'ifSett': False, 'ifGPI': False}

    # 读取报文
    msgFile = open(f'MSG/{env}/103_GPI.txt', 'r', encoding='utf-8')

    msg = msgFile.read().replace("","").replace("","")

    # 修改报文
    swf = SwiftMsg(msg)

    swf.update(data=xldata)

    msg1 = swf.tostring()

    # 修改后的报文插入数据库
    mqReceiver = SwiftMqReceiver()

    mqReceiver.run(data= msg1)

    print("103_gpi报文已入表,sysid:",mqReceiver.sys_id)

    # 收报批量执行是否执行成功
    inbox = waitSWFBatchRun(mqReceiver.sys_id)

    # 清分批量执行是否执行成功
    refno = waitClearBatchRun(inbox)

    if inbox:

        ret['inbox'] = inbox

        print("报文序号:", inbox)

        if refno:

            ret['refno'] = refno

            print("业务编号:", refno)

            # 收妥批量是否执行成功
            if waitAckBatchRun(refno):

                ret['ifAck'] = True

                # 解付批量是否执行成功
                if waitSettBatchRun(refno):

                    ret['ifSett'] = True

                    if ifGpiReturn(inbox):

                        ret['ifGPI'] = True

                        print("==103收报整流程成功==")

                        return  ret

                    else:

                        print("==103收报整流程未完成==")

                        return  ret

                else:

                    return  ret

            else:

                return  ret

        else:

            return ret

    else:

        return  ret



if __name__ == '__main__':

    test_msgDeal({'59': '/OSA15000108343651\nLIAN ZDH TEST CUST001'},'FAT2')

