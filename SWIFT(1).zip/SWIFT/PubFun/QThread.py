#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/5/11 15:18
from PyQt5.QtCore import *
from PubFun.pubFunc import waitSWFBatchRun
from PubFun.pubFunc import waitClearBatchRun
from PubFun.pubFunc import waitAckBatchRun
from PubFun.pubFunc import waitSettBatchRun
from PubFun.pubFunc import ifGpiReturn


class Worker_103(QThread):

    def __init__(self,sysid):
        super(Worker_103,self).__init__()
        self.sysid = sysid
        self.ret = {'inbox':'','refno':'','ifAck':False,'ifSett':False,'ifGPI':False}

    def run(self):
        # 线程相关的代码
        # 收报批量执行是否执行成功
        self.inbox = waitSWFBatchRun(self.sysid)

        print("报文序号:",self.inbox)

        # 清分批量执行是否执行成功
        self.refno = waitClearBatchRun(self.inbox)

        print("业务编号:", self.refno)

        if self.inbox :

            self.ret['inbox'] = self.inbox

            if self.refno:

                self.ret['refno'] = self.refno

                # 收妥批量是否执行成功
                if waitAckBatchRun(self.refno):

                    self.ret['ifAck'] = True

                    # 解付批量是否执行成功
                    if waitSettBatchRun(self.refno):

                        self.ret['ifSett'] = True

                        if ifGpiReturn(self.inbox):

                            self.ret['ifGPI'] = True

                            print("==103收报整流程成功==")

                            return

                        else:

                            print("==103收报整流程未完成==")

                            return

                    else:

                        print("==解付批量未成功==")

                        return

                else:

                    print("==收妥批量未成功==")

                    return

            else:

                print("==清分批量未成功==")

                return

        else:

            print("==收报批量未成功==")

            return








class Worker_103_910_202(QThread):

    def __init__(self,sysid):
        super(Worker_103_910_202,self).__init__()
        self.sysid = sysid

    def run(self):
        # 线程相关的代码
        # 收报批量执行是否执行成功
        inbox = waitSWFBatchRun(self.sysid)

        print("报文序号:",inbox)

        # 清分批量执行是否执行成功
        ref_no = waitClearBatchRun(inbox)

        print("业务编号:", ref_no)

