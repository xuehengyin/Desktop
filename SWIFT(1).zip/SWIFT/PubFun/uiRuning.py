#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/6/20 10:28

from selenium import webdriver
import win32api
import win32con
from selenium.webdriver.common.by import By
import PubFun.pubFunc
from selenium.webdriver.common.action_chains import ActionChains
from PubFun.readoracle import readOracle
import time
import json

def runAck(ret:dict,acctInfo:dict):
    cursor = readOracle().connect()
    cursor.execute(f"select b.Send_Dialog from fbs.msg_inbox b where b.inbox='{ret['inbox']}'")
    refNo = cursor.fetchall()[0][0].strip()
    f = open('Url.json', 'r+', encoding='utf-8')
    fileContent = json.load(f)
    driver = webdriver.Chrome()
    driver.get(fileContent['ENV'])
    driver.set_window_size(1936, 1056)
    driver.find_element(By.ID, "_FBS_USER_BRNO").clear()
    driver.find_element(By.ID, "_FBS_USER_BRNO").send_keys("9998")
    driver.find_element(By.ID, "_FBS_USER_STAFFNO").click()
    driver.find_element(By.ID, "_FBS_USER_STAFFNO").send_keys("YELAN")
    driver.find_element(By.ID, "PASSWORD").clear()
    driver.find_element(By.ID, "PASSWORD").send_keys("SDBFBS")
    driver.find_element(By.NAME, "Submit").click()
    time.sleep(2)
    driver.switch_to.default_content()
    driver.switch_to_frame(driver.find_element(By.ID, "mainFrame"))
    driver.find_element(By.ID, "TAB_DELIVER").click()
    driver.switch_to_frame(driver.find_element(By.ID, "IFRAME_DELIVER_QUEUE"))
    time.sleep(2)
    driver.find_element(By.XPATH, '//*[@id="DO_DELIVER_QUEUE_GRID_BAR_left"]/table/tbody/tr/td[1]/div').click()
    time.sleep(2)
    driver.find_element(By.ID, "_UF_DOT_INBOX").send_keys(ret['inbox'])
    driver.find_element(By.XPATH, '//*[@id="_FBS_TRAN_BRANCH_ISALL"]/option[3]').click()
    driver.find_element(By.XPATH, '//*[@id="searchTaskWindow"]/table/tbody/tr[18]/td/a[1]/span').click()
    driver.find_element(By.XPATH, '//*[@id="searchTaskWindow"]/table/tbody/tr[18]/td/a[2]/span').click()
    time.sleep(1)
    rc = driver.find_element(By.XPATH, '//*[@id="1"]/td[1]')
    ActionChains(driver).double_click(rc).perform()
    time.sleep(2)
    driver.find_element(By.ID,"MSG_INBOX_DOT_CUST_NO").click()
    driver.find_element(By.ID,"LOOKUP").click()
    time.sleep(1)
    driver.switch_to_frame(driver.find_element(By.ID, "lookupIFrame"))
    driver.find_element(By.ID,"CUST_ENM").clear()
    driver.find_element(By.ID,"CUST_NO").send_keys(acctInfo["CUST_NO"])
    driver.find_element(By.ID, "btn-lookup-query").click()
    time.sleep(3)
    driver.find_element(By.XPATH,'//*[@id="1"]/td[1]').click()
    driver.find_element(By.ID,'btn-lookup-ok').click()
    time.sleep(2)
    driver.switch_to.parent_frame()
    driver.find_element(By.ID,"MSG_INBOX_DOT_AC_FLAG").click()
    clickEnterKey()
    time.sleep(2)
    driver.find_element(By.ID,"SUBMIT2").click()
    time.sleep(2)
    clickEnterKey()
    time.sleep(2)
    driver.get(fileContent['ENV'])
    driver.set_window_size(1936, 1056)
    driver.find_element(By.ID, "_FBS_USER_BRNO").clear()
    driver.find_element(By.ID, "_FBS_USER_BRNO").send_keys("9998")
    driver.find_element(By.ID, "_FBS_USER_STAFFNO").click()
    driver.find_element(By.ID, "_FBS_USER_STAFFNO").send_keys("HZCJ")
    driver.find_element(By.ID, "PASSWORD").clear()
    driver.find_element(By.ID, "PASSWORD").send_keys("SDBFBS")
    driver.find_element(By.NAME, "Submit").click()
    driver.switch_to_frame(driver.find_element(By.ID, "mainFrame"))
    driver.find_element(By.ID, "TAB_FLOWQUEUE").click()
    driver.switch_to_frame(driver.find_element(By.ID, "IFRAME_FLOW_QUEUE"))
    time.sleep(2)
    driver.find_element(By.XPATH,'//*[@id="DO_FLOW_QUEUE_GRID_BAR_left"]/table/tbody/tr/td[1]').click()
    time.sleep(2)
    driver.find_element(By.NAME, "FBS_REF_FIRST").send_keys(refNo)
    driver.find_element(By.XPATH,'//*[@id="searchTaskWindow"]/table/tbody/tr[16]/td/a[1]/span').click()
    time.sleep(1)
    driver.find_element(By.XPATH,'//*[@id="searchTaskWindow"]/table/tbody/tr[16]/td/a[2]/span').click()
    time.sleep(2)
    driver.find_element(By.XPATH,'//*[@id="1"]/td[2]/a/img').click()
    time.sleep(2)
    driver.find_element(By.ID,'ACCEPT').click()
    time.sleep(2)
    clickEnterKey()
    time.sleep(2)
    driver.close()

    cursor = readOracle().connect()
    cursor.execute(f"select b.ref_first from fbs.msg_inbox b where b.inbox='{ret['inbox']}'")
    iRNo = cursor.fetchall()[0][0].strip()

    if PubFun.pubFunc.waitAckBatchRun(iRNo):
        print("界面收妥操作成功！")
    else:
        print("界面收妥操作失败！")


def clickEnterKey():
    win32api.keybd_event(13, 0, 0, 0)
    win32api.keybd_event(13, 0, win32con.KEYEVENTF_KEYUP, 0)





