#!.usr.bin.env python
# -*- coding: utf-8 -*-
# @Author:Created by Xuehy
# @Time : 2022/4/20 14:29
import os
import time
import json
import copy
import openpyxl
import PubFun.uiRuning
from PubFun.readoracle import readOracle

def sqlData(path,sqlName):

    """数据库查询"""
    jsonData0 = open(path, 'r', encoding='utf-8')

    jsonData = json.load(jsonData0)

    cursor = readOracle().connect()

    try:

        cursor.execute(jsonData[sqlName])

        ret = cursor.fetchall()

        ret2 = []

        for i in ret:

            ret2.append(list(i))

        print("数据库查询结果:::",ret2)

        return ret2

    except Exception as e:

        print(e)

    finally:

        jsonData0.close()

        cursor.close()

# 读取excel数据
def excelData(filePath:str,sheetName:str='Sheet1',sqldata:list=[]):

    xlsx = openpyxl.load_workbook(filePath)

    try:
        """EXCEL读取"""

        sheetNames = xlsx.sheetnames

        xlsxData = xlsx[sheetNames[0]]

        if sheetName in sheetNames:

            xlsxData = xlsx[sheetName]

        #先确认需要读取的行数 执行结果及以下的行不读取
        num = xlsxData.max_row + 1

        for r in range(1, xlsxData.max_row + 1):

            if xlsxData.cell(row=r, column=1).value == '执行结果':

                num = r

                break

        retList = []

        for i in range(2,xlsxData.max_column+1):

            ret = {}

            for j in range(2,num):

                ret[xlsxData.cell(row=j, column=1).value] = xlsxData.cell(row=j, column=i).value

            retList.append(ret)

        retList2 = []

        if len(sqldata) > 0 and len(sqldata[0]) > 0:

            for data in sqldata:

                for ret in retList:

                    ret['59'] = data[0]

                    retList2.append(copy.deepcopy(ret))

        if len(retList2) > 0:

            return retList2
        else:
            return retList

    except Exception as e:

        print(e)

    finally:

        xlsx.close()

# 等待swift收报批量
def waitSWFBatchRun(sys_id):

    cursor = readOracle().connect()

    try:
        # 300秒内每秒查一次收报状态
        for i in range(0,300):

            cursor.execute(f"select s.status,s.inbox from FBS.FBS_SWF_MSG s where s.sys_id = '{sys_id}'")

            ret = cursor.fetchall()

            if i % 10 == 0:

                print(".")

            if len(ret) > 0:

                if ret[0][0] == '1':

                    print("==成功收报==")

                    return ret[0][1]

                if ret[0][0] == '4':

                    print("==收报格式错误==")

                    return False

            time.sleep(1)

        print("==超五分钟收报批量未执行==")

        return False

    except Exception as e:

        print(e)

    finally:

        cursor.close()

# 等待清分批量
def waitClearBatchRun(inbox):

    cursor = readOracle().connect()

    try:
        # 300秒内每秒查一次收报状态
        for i in range(0, 60):

            cursor.execute(f"select b.status,b.ref_first from fbs.msg_inbox b where b.inbox='{inbox}'")

            ret = cursor.fetchall()

            if i % 10 == 0:

                print(".")

            if len(ret) > 0:

                if ret[0][0] == '1':

                    print("==清分成功==")

                    return ret[0][1]

            time.sleep(1)

        print("==超一分钟清分批量未执行==")

        return False

    except Exception as e:

        print(e)

# 等待收妥批量执行
def waitAckBatchRun(ref_no):

    cursor = readOracle().connect()

    try:
        # 30秒内每秒查一次收报状态
        for i in range(0, 30):

            cursor.execute(f"select w.status from fbs.fbs_workflow w where w.ref_no='{ref_no}'")

            ret = cursor.fetchall()

            if i % 10 == 0:

                print(".")

            if len(ret) > 0:

                if ret[0][0] == '1':

                    print("==已收妥==")

                return True

            time.sleep(1)

        print("==超三十秒收妥批量未执行==")

        return False

    except Exception as e:

        print(e)

# 等待解付批量执行
def waitSettBatchRun(ref_no):

    cursor = readOracle().connect()

    try:
        # 60秒内每秒查一次收报状态
        for i in range(0, 120):

            cursor.execute(f"select count(*) from fbs.fbs_workflow w where w.ref_no='{ref_no}' and w.tran_code = '0807'")

            ret = cursor.fetchall()

            if i % 10 == 0:

                print(".")

            if len(ret) > 0:

                if ret[0][0] > 0:

                    print("==解付批量已执行==")

                    return True

            time.sleep(1)

        print("==超两分分钟解付批量未执行==")

        return False

    except Exception as e:

        print(e)

# 是否返回GPI
def ifGpiReturn(inbox):

    cursor = readOracle().connect()

    try:
        # 60秒内每秒查一次收报状态
        for i in range(0, 60):

            cursor.execute(f"select g.msg_uetr from fbs.fbs_msg_gpi g where g.msg_no='{inbox}'")

            ret = cursor.fetchall()

            ret2 = []

            if len(ret) > 0:

                cursor.execute(f"select g.Mt from fbs.fbs_msg_gpi g where g.msg_uetr = '{ret[0][0]}' and g.send_recv = 'S'")

                ret2 = cursor.fetchall()

            if i % 10 == 0:

                print(".")

            if len(ret2) > 0:

                if ret2[0][0] == '199':

                    print("==GPI值已返回==")

                    return True

            time.sleep(1)

        print("==超五分钟GPI值未返回==")

        return False

    except Exception as e:

        print(e)

#设置数据库信息
def setDataBase(dataType):

    try:
        f = open('DataBase.json','r+',encoding='utf-8')

        fileContent = json.load(f)

        fileContent['ENV'] = fileContent[dataType]

        print("当前数据库为：",fileContent['ENV'])

        f.close()

        f2 = open('DataBase.json', 'w+', encoding='utf-8')

        json.dump(fileContent,f2)

        f2.close()

    except Exception as e:

        print(e)

#设置url地址
def setUrl(dataType):

    try:
        f = open('Url.json','r+',encoding='utf-8')

        fileContent = json.load(f)

        fileContent['ENV'] = fileContent[dataType]

        print("当前数据库为：",fileContent['ENV'])

        f.close()

        f2 = open('Url.json', 'w+', encoding='utf-8')

        json.dump(fileContent,f2)

        f2.close()

    except Exception as e:

        print(e)

def writeRet(filePath,sheetName,ret:dict,index):

    f = openpyxl.load_workbook(filePath)

    try:

        content = f[sheetName]

        num = 0

        for i in range(1,content.max_row+1):

            if content.cell(row=i, column=1).value == '执行结果':

                num = i

                break

        if num == 0:

            content.cell(row=content.max_row+1, column=1).value = '执行结果'

            num = content.max_row

        content.cell(row=num + 1,column=1).value = 'inbox:'
        content.cell(row=num + 2,column=1).value = 'refno:'
        content.cell(row=num + 3,column=1).value = '是否收妥:'
        content.cell(row=num + 4,column=1).value = '是否解付:'

        if ret['inbox']:
            content.cell(row=num + 1, column=index+2).value = ret['inbox']

        if ret['refno']:
            content.cell(row=num + 2, column=index+2).value = ret['refno']

        if ret['ifAck']:
            content.cell(row=num + 3, column=index+2).value = '是'
        else:
            content.cell(row=num + 3, column=index+2).value = '否'

        if ret['ifSett']:
            content.cell(row=num + 4, column=index+2).value = '是'
        else:
            content.cell(row=num + 4, column=index+2).value = '否'

        f.save(filePath)

        print(f"==第{index+1}条报文结果回写完毕==")

        return

    except Exception as e:

        print(e)

    finally:

        f.close()

def getAccount(dataType,msgType):
    f = open(f'D:/SWIFT/MSG/{dataType}/{msgType}.txt','r',encoding='utf-8')
    acct = f.read().split(':59:/')[1].split('\n')[0]
    acctRet = {}
    cursor = readOracle().connect()
    cursor.execute(f"select c.cust_no from fbs.fbs_ctacct c where c.custacct_no = '{acct}'")
    ret = cursor.fetchall()
    acctRet['CUST_NO'] = ret[0][0]
    return acctRet



def runUi(ret:dict,dataType,msgType):
    if ret['inbox']:
        if ret['ifAck']:
            print("执行解付界面流程")

        else:
            print("执行收妥界面流程")
            acctInfo = getAccount(dataType, msgType)
            PubFun.uiRuning.runAck(ret,acctInfo)
    return



if __name__ == '__main__':
    runUi({'inbox': '22845679', 'refno': '', 'ifAck': False, 'ifSett': False, 'ifGPI': False},'FAT2','103')
    #22845680   22845679    22845678  22845677