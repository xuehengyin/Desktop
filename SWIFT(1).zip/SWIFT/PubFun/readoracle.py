#!.usr.bin.env python
# -*- coding: utf-8 -*-
import copy
from datetime import datetime
import os
import json
import cx_Oracle as ol


class readOracle(object):
    def __init__(self):

        f = open('DataBase.json', 'r+', encoding='utf-8')

        fileContent = json.load(f)

        self.db = fileContent['ENV']

        return

    def readdata(self, sql, resultnm: list):
        """
        用于查询基本参数,如客户信息等,查询返回所有结果的第一条
        2021/03/05 修改sqldefine类型,同时支持str,list两种方式;支持多个sql,一个nodelist的拼接输出
        :return list
        """
        # print("注意sql查询结果字段的顺序需要与resultnm中的一致")
        if not len(resultnm) > 0:
            raise Exception("查询结果保存对应字段为空,请检查")
        if isinstance(sql, list):
            sqllist = sql
        elif isinstance(sql, str):
            sqllist = [sql]
        else:
            raise Exception("sql传入时,多个sql请使用list拼装查询语句,单个sql使用查询语句")
        sqldefine = ""
        try:
            conn = ol.connect(self.db)
            curs = conn.cursor()
            resultlist = []
            for sqldefine in sqllist:  # 循环执行每个sql
                resultdict = {}  # 通过查询结果和nodelist按顺序组合
                resultdict.clear()
                tempresult = curs.execute(sqldefine).fetchall() # 查询结果为
                for tmpX in tempresult:  # 循环查询结果的每一行数据
                    tmpRow = []
                    tmpRow.clear()
                    for i in range(0, len(tmpX)):
                        if isinstance(tmpX[i], str):
                            tmpRow.append(tmpX[i].strip())
                        elif isinstance(tmpX[i], int):
                            tmpRow.append(str(tmpX[i]))
                        elif isinstance(tmpX[i],float):
                            tmpRow.append(str(tmpX[i]))
                            # print("float类型请通过to_char控制精度")
                        elif isinstance(tmpX[i], datetime):
                            tmpRow.append(tmpX[i].strftime("%Y/%m/%d %H:%M:%S"))
                        elif isinstance(tmpX[i], ol.LOB):
                            tmpRow.append(tmpX[i].read())
                        elif tmpX[i] is None:
                            tmpRow.append("")
                        else:
                            tmpRow.append(tmpX[i])
                    for i in range(0, len(resultnm)):
                        resultdict[resultnm[i]] = tmpRow[i]
                    tmprdic = copy.deepcopy(resultdict)
                    resultlist.append(tmprdic)
                if len(resultdict) == 0:
                    for i in range(0, len(resultnm)):
                        resultdict[resultnm[i]] = ""
                    tmprdic = copy.deepcopy(resultdict)
                    resultlist.append(tmprdic)
                # print(NOW(), "执行sql结束")
            curs.close()
            conn.close()
            # 这个检查阻断型太强 暂时注释
            # if checkresultlist(resultlist):
            return resultlist
        except Exception as e:
            raise Exception(self.db, sqldefine, "Excute Error", e)

    def readlist(self,sql: str):
        """
        取出查询结果后转化为str,返回list
        """
        resultlist = []
        conn = ol.connect(self.db)
        curs = conn.cursor()
        try:
            tmplist = curs.execute(sql).fetchall()
            for tmpX in tmplist:
                tmpRow = []
                tmpRow.clear()
                for i in range(0, len(tmpX)):
                    if isinstance(tmpX[i], str):
                        tmpRow.append(tmpX[i].strip())
                    elif isinstance(tmpX[i], int):
                        tmpRow.append(str(tmpX[i]))
                    elif isinstance(tmpX[i], float):
                        tmpRow.append(str(tmpX[i]))
                        print("数据库字段类型为number时,如果需要控制精度请通过查询sql,to_char保留精度")
                    elif isinstance(tmpX[i], datetime):
                        tmpRow.append(tmpX[i].strftime("%Y/%m/%d %H:%M:%S"))
                    elif isinstance(tmpX[i], ol.LOB):
                        tmpRow.append(tmpX[i].read())
                    elif tmpX[i] is None:
                        tmpRow.append("")
                    else:
                        print(type(tmpX[i]))
                        tmpRow.append(tmpX[i])
                resultlist.append(copy.deepcopy(tmpRow))
            return resultlist
        except Exception as e:
            raise Exception(f"执行的sql为[{sql}],错误信息为{e}")

    def fetchall(self,sql: str):
        result = []
        conn = ol.connect(self.db)
        try:
            curs = conn.cursor()
            result = curs.execute(sql).fetchall()
            curs.close()
            conn.commit()
            conn.close()
            return result
        except Exception as e:
            conn.rollback()
            print(f"readoracle.excute执行异常,错误信息为{e.__traceback__}")
            return result
        finally:
            try:
                conn.close()
            except:
                pass

    def getTableCols(self,tableName):
        if not tableName.find(".") > -1:
            raise Exception("请以OWNER.TABLE_NAMES的格式输入表名")
        l = tableName.split(".")
        owner = l[0]
        tablenm = l[1]
        query = f"""SELECT COLUMN_NAME
      FROM ALL_TAB_COLUMNS
     WHERE OWNER = '{owner}'
       AND TABLE_NAME = '{tablenm}'
     ORDER BY COLUMN_ID"""
        conn = ol.connect(self.db)
        try:
            curs = conn.cursor()
            r = curs.execute(query).fetchall()
            result = []
            for c in r:
                result.append(c[0])
            curs.close()
            conn.close()
            if len(result) == 0:
                raise Exception(f"未查询到[{tableName}]的列名")
            return result
        except Exception as e:
            print (f"readoracle.excute执行异常,错误信息为{e.__traceback__}")
            return []
        finally:
            try:
                conn.close()
            except:
                pass

    def excute(self,sql):
        """
        用于执行update, insert, delete语句
        :param sql:
        :return:
        """
        if "DROP" in sql or "TRUNCATE" in sql:
            print("禁止执行删表语句")
            return False
        conn = ol.connect(self.db)
        try:
            curs = conn.cursor()
            curs.execute(sql)
            curs.close()
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            conn.rollback()
            print(f"readoracle.excute执行[{sql}]异常,错误信息为{e}")
            return False
        finally:
            try:
                conn.close()
            except:
                pass

    def connect(self):
        """
        定义一个方法便于灵活使用
        :return:
        """
        conn = ol.connect(self.db).cursor()
        return conn

def checkresultlist(resultlist: list):
    """
    增加对sql执行结果的检查,如果一条查询记录的每项内容都是空,则认为测试环境中没有查询到对应的测试数据
    """
    totalvalue = ""
    try:
        for value in resultlist[0].values():
            totalvalue = totalvalue + value
        if len(totalvalue) == 0:
            return False
        else:
            return True
    except Exception as e:
        raise Exception("checkresultlist, error", e)


def tranList2Dict(l : list):
    """
    :param l: 传入的list大于等于两行, 以第一行的值为key, 余下行对应位置为value进行转化
    :return:
    """
    result = []
    nameList = l[0]
    for i in range(1,len(l)):
        tmpDict = {}
        for vi in range(0,len(l[i])):
            tmpDict[nameList[vi]] = l[i][vi]
        result.append(tmpDict)
    return result