#!.usr.bin.env python
# -*- coding: utf-8 -*-

import cx_Oracle as ol
import json


class SwiftMqReceiver(object):
    def __init__(self):
        self.msg_data = ""
        self.sys_id = 0
        self.status = "0"
        self.file_type = "I"
        f = open('DataBase.json', 'r+', encoding='utf-8')
        fileContent = json.load(f)
        self.conn = ol.connect(fileContent['ENV'])
        self.cursor = self.conn.cursor()
        return

    def run(self, data, fileType = None):
        sql = None
        if fileType is None:
            fileType = "I"
        try:
            self.sys_id = self.cursor.execute("SELECT MAX(SYS_ID)+1 FROM FBS.FBS_SWF_MSG").fetchone()[0]
            if self.sys_id is None:
                self.sys_id = "0000000000001"
            # 2021-08-26 增加特殊处理CLOB中有'时,修复会导致sql执行异常的
            if isinstance(data,ol.LOB):
                if "'" in data.read():
                    value = data.read().replace("'","'||''''||'")
                else:
                    value = data.read()
            else:
                if "'" in data:
                    value = data.replace("'","'||''''||'")
                else:
                    value = data
            # 2021-08-26
            sql = "INSERT INTO FBS.FBS_SWF_MSG(SYS_ID, MSG_TIME, MSG_DATA, " \
                  "STATUS,FILE_TYPE) VALUES" + f"('{self.sys_id}',SYSDATE,'{value}','0','{fileType}') "
            self.cursor.execute(sql)
            self.conn.commit()
            return True
        except Exception as e:
            print(f"SwiftMqReceiver.run异常,内容为{e}")
            if sql is not None:
                print(f"执行的sql为[{sql}]")
            self.conn.rollback()
            return False

    def close(self):
        self.conn.disconnect()
        return

